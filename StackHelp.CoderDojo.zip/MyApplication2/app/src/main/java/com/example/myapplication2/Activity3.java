package com.example.myapplication2;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class Activity3 extends Activity {
    private ViewGroup container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
    }

    @Override
    public View onCreateView(String name, Context context, AttributeSet attrs) {
        return getLayoutInflater().inflate(R.layout.activity_2,container,false);
    }
}

